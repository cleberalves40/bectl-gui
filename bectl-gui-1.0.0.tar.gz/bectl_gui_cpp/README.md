# bectl GUI (C++/Qt6) – Gerenciador de Boot Environments (FreeBSD)

Versão em **C++** do gerenciador gráfico de Boot Environments, equivalente à versão Python/PyQt6.
Desenvolvida para comparação de desempenho em **FreeBSD 15.1-STABLE** com o Clang/LLVM do sistema.

## Arquitetura (mesma da versão Python)

```
bectl_gui_cpp/
├── CMakeLists.txt
├── README.md
└── src/
    ├── main.cpp                 # Ponto de entrada
    ├── logic/
    │   ├── bectlmanager.h       # Lógica de comandos bectl + qt-sudo
    │   └── bectlmanager.cpp
    └── gui/
        ├── mainwindow.h         # Interface gráfica Qt6
        └── mainwindow.cpp
```

| Parte              | Localização              | Responsabilidade                          |
|--------------------|--------------------------|-------------------------------------------|
| **Lógica**         | `src/logic/bectlmanager.*` | Execução dos comandos `bectl` via QProcess |
| **Interface GUI**  | `src/gui/mainwindow.*`     | Janela Qt6, tabela e diálogos             |
| **Entrada**        | `src/main.cpp`             | Inicialização da QApplication             |

### Elevação de privilégios com qt-sudo

Todas as operações de escrita são executadas assim:

```text
qt-sudo bectl create nome-do-be
qt-sudo bectl activate nome-do-be
qt-sudo bectl destroy -F nome-do-be
...
```

## Funcionalidades (idênticas à versão Python)

- Listar todos os Boot Environments (`bectl list -H`)
- Destaque visual: verde = ativo agora, amarelo = ativo no próximo boot
- Criar novo BE (origem opcional + flag `-r`)
- Ativar permanentemente ou temporariamente (`-t`)
- Renomear
- **Destruir um ou vários BEs** (Ctrl+clique / Shift+clique)
- Proteção automática contra destruição do BE ativo
- Operações na thread da GUI (necessário para o qt-sudo abrir o diálogo de senha com segurança)

## Requisitos (FreeBSD 15.1-STABLE)

```bash
# Compilador e ferramentas de build (já vêm no sistema ou base)
pkg install cmake ninja

# Qt6
pkg install qt6-base qt6-tools

# Elevação de privilégios
pkg install qt-sudo
```

- Clang/LLVM do sistema ( FreeBSD 15.1 já inclui )
- CMake ≥ 3.16
- Qt 6.x

## Compilação

```bash
# 1. Entrar no diretório do projeto
cd bectl_gui_cpp

# 2. IMPORTANTE: alinhar timestamps ao relógio da máquina
#    (evita o aviso "Clock skew detected" do gmake)
sh fix-timestamps.sh
#    ou:  find . -exec touch {} +

# 3. Configurar (gera build/ fora da árvore de fontes)
cmake -B build -S . -G Ninja \
      -DCMAKE_BUILD_TYPE=Release \
      -DCMAKE_CXX_COMPILER=clang++

# 4. Compilar
cmake --build build -j$(sysctl -n hw.ncpu)

# 5. Executar
./build/bectl_gui
```

### Alternativa com Make (sem Ninja)

```bash
cd bectl_gui_cpp
sh fix-timestamps.sh          # evita Clock skew
rm -rf build                  # limpa build anterior incompleto, se houver
cmake -B build -S . -DCMAKE_BUILD_TYPE=Release -DCMAKE_CXX_COMPILER=clang++
cmake --build build -j$(sysctl -n hw.ncpu)
./build/bectl_gui
```

### Se aparecer "Clock skew detected"

Isso ocorre quando a data dos arquivos extraídos está à frente do relógio do sistema.
Correção:

```bash
# Opcional: sincronizar o relógio (como root)
# ntpdate -u pool.ntp.org
# ou: service ntpd restart

find . -exec touch {} +
rm -rf build
cmake -B build -S . -DCMAKE_BUILD_TYPE=Release -DCMAKE_CXX_COMPILER=clang++
cmake --build build -j$(sysctl -n hw.ncpu)
```

### Instalação opcional no sistema

```bash
cmake --install build --prefix /usr/local
# binário em /usr/local/bin/bectl_gui
```

## Comparação com a versão Python

| Aspecto              | Python (PyQt6)     | C++ (Qt6)              |
|----------------------|--------------------|------------------------|
| Runtime              | interpretado + Qt  | nativo (binário)       |
| Startup              | mais lento         | mais rápido            |
| Uso de memória       | maior              | menor                  |
| Dependências runtime | Python + PyQt6     | apenas libs Qt6        |
| Interface / UX       | idêntica           | idêntica               |
| Lógica bectl          | subprocess         | QProcess               |
| Elevação             | qt-sudo            | qt-sudo                |

## Correção SIGSEGV (v1.0.1)

A versão anterior usava `QThread` + `Worker` para operações assíncronas. Isso gerava
*segmentation fault* ao destruir/criar BEs por:

1. Double-free do `QThread` (`delete` manual + `deleteLater`)
2. Execução do **qt-sudo** (aplicativo gráfico) fora da thread principal

**Correção:** todas as operações de `bectl`/`qt-sudo` passam a rodar na thread da GUI.
O diálogo de senha do qt-sudo funciona de forma estável e o crash deixa de ocorrer.


## Debug de memória (Valgrind e AddressSanitizer)

### 1) Compilar em Debug (símbolos)

```bash
cd bectl_gui_cpp
sh fix-timestamps.sh
rm -rf build
cmake -B build -S . -DCMAKE_BUILD_TYPE=Debug -DCMAKE_CXX_COMPILER=clang++
cmake --build build -j$(sysctl -n hw.ncpu)
```

### 2) Valgrind (memcheck)

```bash
pkg install valgrind   # se ainda não tiver

# Completo (recomendado)
sh run-valgrind.sh

# Mais rápido
sh run-valgrind.sh --quick

# Gerar suppressions novas
sh run-valgrind.sh --gen-suppressions
```

O log fica em `valgrind-bectl_gui.log`. Foque em:

| Tipo | Significado |
|------|-------------|
| `Invalid read/write` | Acesso fora de bounds → bug real |
| `Use of uninitialised value` | Variável não inicializada |
| `definitely lost` | Vazamento certo no seu código |
| `still reachable` | Muitas vezes ruído de Qt (ver `qt6.supp`) |

**Dica:** use o app normalmente (listar, criar, destruir um BE de teste) e feche a janela.
Assim o Valgrind cobre o caminho que gerava SIGSEGV.

### 3) AddressSanitizer (alternativa, muitas vezes melhor no FreeBSD + Qt)

```bash
sh run-asan.sh
```

Isso recompila em `build-asan/` com `-fsanitize=address,undefined` e executa.
Erros de memória aparecem no terminal com stack trace.

### 4) Interpretar o resultado

- Se o crash do SIGSEGV voltar **sem** Valgrind, rode com ASan — costuma apontar a linha exata.
- Vazamentos `reachable` em `libQt6*.so` são normais e já estão no arquivo `qt6.supp`.
- Qualquer `Invalid read/write` ou `definitely lost` com stack em `bectlmanager.cpp` / `mainwindow.cpp` deve ser investigado.


## Observações de segurança

- O programa **nunca** roda como root. Apenas os comandos `bectl` de escrita são elevados via `qt-sudo`.
- O usuário precisa estar autorizado no `sudoers` ou no `doas.conf`.
- A destruição de BEs é irreversível — sempre há confirmação na interface.

## Licença

Código de exemplo / demonstração. Use e modifique livremente.

## UI estilo OctoPKG (atualização)

A interface Qt6 foi reorganizada no espírito do **OctoPKG**:

| Elemento | Descrição |
|----------|-----------|
| **Menu** | Arquivo · Ações · Ajuda |
| **Toolbar** | Ícones + texto (Atualizar, Criar, Ativar, …) |
| **Filtro** | Campo de busca por nome (como pesquisa de pacotes) |
| **Lista** | Tabela com ícones de estado (ativo / reboot / inativo) |
| **Abas** | Informação · Saída (log) · Ajuda |
| **Status** | Mensagem + contagem de BEs |
| **Estilo** | Fusion + stylesheet claro (seleção azul Octopi-like) |

Lógica `BectlManager` e `qt-sudo` permanecem iguais.

## Temas (menu Tema)

Mesmas paletas da GUI GTK3, em QSS Qt6:

OctoPKG (claro), Catppuccin Frappé/Latte/Mocha/Macchiato, Solarized, Selenized, Dracula, Tokyo Night, Nord, Gruvbox, One Dark.

`Ctrl+Shift+T` — próximo tema.

## Atalhos globais

| Atalho | Ação |
|--------|------|
| F5 / Ctrl+R | Atualizar |
| Ctrl+N | Criar |
| Ctrl+Return | Ativar |
| Ctrl+T | Ativar temporário |
| F2 | Renomear |
| Delete | Destruir |
| Ctrl+F | Foco no filtro |
| Ctrl+1/2/3 | Abas |
| Ctrl+Q | Sair |

## Internacionalização (i18n)

Idiomas iniciais:

| Código | Idioma |
|--------|--------|
| `en_US` | English (US) — padrão / fallback |
| `pt_BR` | Português (Brasil) |
| `es_ES` | Español (España) |

Na arranque usa o idioma do sistema (`QLocale::system()`). Se não for pt/es, usa **en_US**.

Menu **Language / Idioma** para mudar em tempo de execução (sem reiniciar).
