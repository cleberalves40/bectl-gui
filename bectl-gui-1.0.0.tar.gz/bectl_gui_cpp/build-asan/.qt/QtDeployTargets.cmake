set(__QT_DEPLOY_TARGET_bectl_gui_FILE /home/cleber/DEVEL/bectl_cpp_Octo/bectl_gui_cpp/build-asan/bectl_gui)
set(__QT_DEPLOY_TARGET_bectl_gui_TYPE EXECUTABLE)
