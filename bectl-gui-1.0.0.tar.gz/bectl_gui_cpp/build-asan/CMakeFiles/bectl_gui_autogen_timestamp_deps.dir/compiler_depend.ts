# CMAKE generated file: DO NOT EDIT!
# Timestamp file for custom commands dependencies management for bectl_gui_autogen_timestamp_deps.
