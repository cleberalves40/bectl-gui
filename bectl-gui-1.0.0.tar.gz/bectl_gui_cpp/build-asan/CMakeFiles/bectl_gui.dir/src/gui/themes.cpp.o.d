CMakeFiles/bectl_gui.dir/src/gui/themes.cpp.o: \
  /usr/lib/clang/21/share/asan_ignorelist.txt \
  /home/cleber/DEVEL/bectl_cpp_Octo/bectl_gui_cpp/src/gui/themes.cpp \
  /home/cleber/DEVEL/bectl_cpp_Octo/bectl_gui_cpp/src/gui/themes.h \
  /usr/local/include/qt6/QtCore/QString \
  /usr/local/include/qt6/QtCore/qstring.h \
  /usr/local/include/qt6/QtCore/qchar.h \
  /usr/local/include/qt6/QtCore/qglobal.h \
  /usr/include/c++/v1/type_traits /usr/include/c++/v1/__config \
  /usr/include/c++/v1/__config_site \
  /usr/include/c++/v1/__configuration/abi.h \
  /usr/include/c++/v1/__configuration/compiler.h \
  /usr/include/c++/v1/__configuration/platform.h \
  /usr/include/c++/v1/__configuration/availability.h \
  /usr/include/c++/v1/__configuration/language.h \
  /usr/include/c++/v1/__type_traits/add_cv_quals.h \
  /usr/include/c++/v1/__type_traits/add_pointer.h \
  /usr/include/c++/v1/__type_traits/is_referenceable.h \
  /usr/include/c++/v1/__type_traits/void_t.h \
  /usr/include/c++/v1/__type_traits/is_void.h \
  /usr/include/c++/v1/__type_traits/integral_constant.h \
  /usr/include/c++/v1/__type_traits/remove_reference.h \
  /usr/include/c++/v1/__type_traits/add_reference.h \
  /usr/include/c++/v1/__type_traits/aligned_storage.h \
  /usr/include/c++/v1/__cstddef/size_t.h \
  /usr/include/c++/v1/__type_traits/type_list.h \
  /usr/include/c++/v1/__type_traits/aligned_union.h \
  /usr/include/c++/v1/__type_traits/alignment_of.h \
  /usr/include/c++/v1/__type_traits/common_type.h \
  /usr/include/c++/v1/__type_traits/conditional.h \
  /usr/include/c++/v1/__type_traits/decay.h \
  /usr/include/c++/v1/__type_traits/is_array.h \
  /usr/include/c++/v1/__type_traits/is_function.h \
  /usr/include/c++/v1/__type_traits/remove_cv.h \
  /usr/include/c++/v1/__type_traits/remove_extent.h \
  /usr/include/c++/v1/__type_traits/is_same.h \
  /usr/include/c++/v1/__type_traits/remove_cvref.h \
  /usr/include/c++/v1/__type_traits/type_identity.h \
  /usr/include/c++/v1/__utility/declval.h \
  /usr/include/c++/v1/__utility/empty.h \
  /usr/include/c++/v1/__type_traits/enable_if.h \
  /usr/include/c++/v1/__type_traits/extent.h \
  /usr/include/c++/v1/__type_traits/has_virtual_destructor.h \
  /usr/include/c++/v1/__type_traits/is_abstract.h \
  /usr/include/c++/v1/__type_traits/is_arithmetic.h \
  /usr/include/c++/v1/__type_traits/is_floating_point.h \
  /usr/include/c++/v1/__type_traits/is_integral.h \
  /usr/include/c++/v1/__type_traits/is_assignable.h \
  /usr/include/c++/v1/__type_traits/is_base_of.h \
  /usr/include/c++/v1/__type_traits/is_class.h \
  /usr/include/c++/v1/__type_traits/is_compound.h \
  /usr/include/c++/v1/__type_traits/is_fundamental.h \
  /usr/include/c++/v1/__type_traits/is_null_pointer.h \
  /usr/include/c++/v1/__cstddef/nullptr_t.h \
  /usr/include/c++/v1/__type_traits/is_const.h \
  /usr/include/c++/v1/__type_traits/is_constructible.h \
  /usr/include/c++/v1/__type_traits/is_convertible.h \
  /usr/include/c++/v1/__type_traits/conjunction.h \
  /usr/include/c++/v1/__type_traits/disjunction.h \
  /usr/include/c++/v1/__type_traits/lazy.h \
  /usr/include/c++/v1/__type_traits/is_destructible.h \
  /usr/include/c++/v1/__type_traits/is_reference.h \
  /usr/include/c++/v1/__type_traits/remove_all_extents.h \
  /usr/include/c++/v1/__type_traits/is_empty.h \
  /usr/include/c++/v1/__type_traits/is_enum.h \
  /usr/include/c++/v1/__type_traits/is_literal_type.h \
  /usr/include/c++/v1/__type_traits/is_member_pointer.h \
  /usr/include/c++/v1/__type_traits/is_nothrow_assignable.h \
  /usr/include/c++/v1/__type_traits/is_nothrow_constructible.h \
  /usr/include/c++/v1/__type_traits/is_nothrow_destructible.h \
  /usr/include/c++/v1/__type_traits/is_object.h \
  /usr/include/c++/v1/__type_traits/is_pod.h \
  /usr/include/c++/v1/__type_traits/is_pointer.h \
  /usr/include/c++/v1/__type_traits/is_polymorphic.h \
  /usr/include/c++/v1/__type_traits/is_scalar.h \
  /usr/include/c++/v1/__type_traits/is_signed.h \
  /usr/include/c++/v1/__type_traits/is_standard_layout.h \
  /usr/include/c++/v1/__type_traits/is_trivial.h \
  /usr/include/c++/v1/__type_traits/is_trivially_assignable.h \
  /usr/include/c++/v1/__type_traits/is_trivially_constructible.h \
  /usr/include/c++/v1/__type_traits/is_trivially_copyable.h \
  /usr/include/c++/v1/cstdint /usr/include/stdint.h \
  /usr/include/sys/cdefs.h /usr/include/sys/_decls.h \
  /usr/include/sys/_visible.h /usr/include/sys/_types.h \
  /usr/include/machine/_types.h /usr/include/x86/_types.h \
  /usr/include/machine/_limits.h /usr/include/x86/_limits.h \
  /usr/include/machine/_stdint.h /usr/include/x86/_stdint.h \
  /usr/include/sys/_stdint.h \
  /usr/include/c++/v1/__type_traits/is_trivially_destructible.h \
  /usr/include/c++/v1/__type_traits/is_union.h \
  /usr/include/c++/v1/__type_traits/is_unsigned.h \
  /usr/include/c++/v1/__type_traits/is_volatile.h \
  /usr/include/c++/v1/__type_traits/make_signed.h \
  /usr/include/c++/v1/__type_traits/copy_cv.h \
  /usr/include/c++/v1/__type_traits/make_unsigned.h \
  /usr/include/c++/v1/__type_traits/rank.h \
  /usr/include/c++/v1/__type_traits/remove_const.h \
  /usr/include/c++/v1/__type_traits/remove_pointer.h \
  /usr/include/c++/v1/__type_traits/remove_volatile.h \
  /usr/include/c++/v1/__type_traits/result_of.h \
  /usr/include/c++/v1/__type_traits/invoke.h \
  /usr/include/c++/v1/__type_traits/is_core_convertible.h \
  /usr/include/c++/v1/__type_traits/is_reference_wrapper.h \
  /usr/include/c++/v1/__fwd/functional.h \
  /usr/include/c++/v1/__type_traits/nat.h \
  /usr/include/c++/v1/__utility/forward.h \
  /usr/include/c++/v1/__type_traits/underlying_type.h \
  /usr/include/c++/v1/__type_traits/is_final.h \
  /usr/include/c++/v1/__type_traits/has_unique_object_representation.h \
  /usr/include/c++/v1/__type_traits/is_aggregate.h \
  /usr/include/c++/v1/__type_traits/is_swappable.h \
  /usr/include/c++/v1/__type_traits/negation.h \
  /usr/include/c++/v1/version /usr/include/c++/v1/cstddef \
  /usr/include/c++/v1/stddef.h /usr/include/stddef.h \
  /usr/include/sys/_null.h /usr/include/c++/v1/__cstddef/byte.h \
  /usr/include/c++/v1/__fwd/byte.h \
  /usr/include/c++/v1/__cstddef/max_align_t.h \
  /usr/include/c++/v1/__cstddef/ptrdiff_t.h /usr/include/c++/v1/utility \
  /usr/include/c++/v1/__utility/move.h \
  /usr/include/c++/v1/__undef_macros \
  /usr/include/c++/v1/__utility/pair.h \
  /usr/include/c++/v1/__compare/common_comparison_category.h \
  /usr/include/c++/v1/__compare/ordering.h \
  /usr/include/c++/v1/__compare/synth_three_way.h \
  /usr/include/c++/v1/__compare/three_way_comparable.h \
  /usr/include/c++/v1/__concepts/common_reference_with.h \
  /usr/include/c++/v1/__concepts/convertible_to.h \
  /usr/include/c++/v1/__concepts/same_as.h \
  /usr/include/c++/v1/__type_traits/common_reference.h \
  /usr/include/c++/v1/__type_traits/copy_cvref.h \
  /usr/include/c++/v1/__concepts/equality_comparable.h \
  /usr/include/c++/v1/__concepts/boolean_testable.h \
  /usr/include/c++/v1/__type_traits/make_const_lvalue_ref.h \
  /usr/include/c++/v1/__concepts/totally_ordered.h \
  /usr/include/c++/v1/__concepts/different_from.h \
  /usr/include/c++/v1/__fwd/array.h /usr/include/c++/v1/__fwd/pair.h \
  /usr/include/c++/v1/__fwd/tuple.h \
  /usr/include/c++/v1/__tuple/tuple_indices.h \
  /usr/include/c++/v1/__utility/integer_sequence.h \
  /usr/include/c++/v1/__tuple/tuple_like_no_subrange.h \
  /usr/include/c++/v1/__fwd/complex.h \
  /usr/include/c++/v1/__tuple/tuple_size.h \
  /usr/include/c++/v1/__tuple/tuple_types.h \
  /usr/include/c++/v1/__type_traits/is_implicitly_default_constructible.h \
  /usr/include/c++/v1/__type_traits/is_replaceable.h \
  /usr/include/c++/v1/__type_traits/is_trivially_relocatable.h \
  /usr/include/c++/v1/__type_traits/unwrap_ref.h \
  /usr/include/c++/v1/__utility/piecewise_construct.h \
  /usr/include/c++/v1/__utility/rel_ops.h \
  /usr/include/c++/v1/__utility/swap.h \
  /usr/include/c++/v1/__utility/exchange.h \
  /usr/include/c++/v1/__utility/as_const.h \
  /usr/include/c++/v1/__utility/in_place.h /usr/include/c++/v1/compare \
  /usr/include/c++/v1/cmath /usr/include/c++/v1/__math/hypot.h \
  /usr/include/c++/v1/__math/abs.h \
  /usr/include/c++/v1/__math/exponential_functions.h \
  /usr/include/c++/v1/__type_traits/promote.h \
  /usr/include/c++/v1/__math/min_max.h \
  /usr/include/c++/v1/__math/roots.h /usr/include/c++/v1/limits \
  /usr/include/c++/v1/__type_traits/is_constant_evaluated.h \
  /usr/include/c++/v1/__math/special_functions.h \
  /usr/include/c++/v1/__math/copysign.h \
  /usr/include/c++/v1/__math/traits.h /usr/include/c++/v1/math.h \
  /usr/include/math.h /usr/include/c++/v1/__math/error_functions.h \
  /usr/include/c++/v1/__math/fdim.h /usr/include/c++/v1/__math/fma.h \
  /usr/include/c++/v1/__math/gamma.h \
  /usr/include/c++/v1/__math/hyperbolic_functions.h \
  /usr/include/c++/v1/__math/inverse_hyperbolic_functions.h \
  /usr/include/c++/v1/__math/inverse_trigonometric_functions.h \
  /usr/include/c++/v1/__math/logarithms.h \
  /usr/include/c++/v1/__math/modulo.h \
  /usr/include/c++/v1/__math/remainder.h \
  /usr/include/c++/v1/__math/rounding_functions.h \
  /usr/include/c++/v1/__math/trigonometric_functions.h \
  /usr/include/c++/v1/initializer_list \
  /usr/include/c++/v1/__tuple/ignore.h \
  /usr/include/c++/v1/__tuple/tuple_element.h \
  /usr/include/c++/v1/cstdlib /usr/include/c++/v1/stdlib.h \
  /usr/include/stdlib.h /usr/include/c++/v1/iosfwd \
  /usr/include/c++/v1/__fwd/fstream.h /usr/include/c++/v1/__fwd/string.h \
  /usr/include/c++/v1/__fwd/memory.h \
  /usr/include/c++/v1/__fwd/memory_resource.h \
  /usr/include/c++/v1/__fwd/ios.h /usr/include/c++/v1/__fwd/istream.h \
  /usr/include/c++/v1/__fwd/ostream.h \
  /usr/include/c++/v1/__fwd/sstream.h \
  /usr/include/c++/v1/__fwd/streambuf.h \
  /usr/include/c++/v1/__std_mbstate_t.h \
  /usr/include/c++/v1/__mbstate_t.h /usr/include/wchar.h \
  /usr/include/_ctype.h /usr/include/runetype.h \
  /usr/include/xlocale/_wchar.h /usr/include/assert.h \
  /usr/include/c++/v1/stdbool.h /usr/include/stdbool.h \
  /usr/local/include/qt6/QtCore/qtcoreglobal.h \
  /usr/local/include/qt6/QtCore/qtversionchecks.h \
  /usr/local/include/qt6/QtCore/qtconfiginclude.h \
  /usr/local/include/qt6/QtCore/qconfig.h \
  /usr/local/include/qt6/QtCore/qtcore-config.h \
  /usr/local/include/qt6/QtCore/qtconfigmacros.h \
  /usr/local/include/qt6/QtCore/qtdeprecationdefinitions.h \
  /usr/local/include/qt6/QtCore/qcompilerdetection.h \
  /usr/local/include/qt6/QtCore/qprocessordetection.h \
  /usr/local/include/qt6/QtCore/qsystemdetection.h \
  /usr/include/c++/v1/atomic \
  /usr/local/include/qt6/QtCore/qtcoreexports.h \
  /usr/local/include/qt6/QtCore/qtdeprecationmarkers.h \
  /usr/local/include/qt6/QtCore/qtclasshelpermacros.h \
  /usr/local/include/qt6/QtCore/qtpreprocessorsupport.h \
  /usr/local/include/qt6/QtCore/qassert.h \
  /usr/local/include/qt6/QtCore/qtnoop.h \
  /usr/local/include/qt6/QtCore/qtypes.h \
  /usr/local/include/qt6/QtCore/qtversion.h \
  /usr/local/include/qt6/QtCore/qtypeinfo.h \
  /usr/local/include/qt6/QtCore/qcontainerfwd.h \
  /usr/local/include/qt6/QtCore/qsysinfo.h \
  /usr/local/include/qt6/QtCore/qlogging.h \
  /usr/local/include/qt6/QtCore/qflags.h \
  /usr/local/include/qt6/QtCore/qcompare_impl.h \
  /usr/include/c++/v1/algorithm \
  /usr/include/c++/v1/__algorithm/adjacent_find.h \
  /usr/include/c++/v1/__algorithm/comp.h \
  /usr/include/c++/v1/__type_traits/desugars_to.h \
  /usr/include/c++/v1/__functional/identity.h \
  /usr/include/c++/v1/__algorithm/all_of.h \
  /usr/include/c++/v1/__algorithm/any_of.h \
  /usr/include/c++/v1/__algorithm/binary_search.h \
  /usr/include/c++/v1/__algorithm/comp_ref_type.h \
  /usr/include/c++/v1/__assert /usr/include/c++/v1/__assertion_handler \
  /usr/include/c++/v1/__log_hardening_failure \
  /usr/include/c++/v1/__verbose_abort /usr/include/c++/v1/__verbose_trap \
  /usr/include/c++/v1/__algorithm/lower_bound.h \
  /usr/include/c++/v1/__algorithm/half_positive.h \
  /usr/include/c++/v1/__algorithm/iterator_operations.h \
  /usr/include/c++/v1/__algorithm/iter_swap.h \
  /usr/include/c++/v1/__algorithm/ranges_iterator_concept.h \
  /usr/include/c++/v1/__iterator/concepts.h \
  /usr/include/c++/v1/__concepts/arithmetic.h \
  /usr/include/c++/v1/__concepts/assignable.h \
  /usr/include/c++/v1/__concepts/constructible.h \
  /usr/include/c++/v1/__concepts/destructible.h \
  /usr/include/c++/v1/__concepts/copyable.h \
  /usr/include/c++/v1/__concepts/movable.h \
  /usr/include/c++/v1/__concepts/swappable.h \
  /usr/include/c++/v1/__concepts/class_or_enum.h \
  /usr/include/c++/v1/__concepts/derived_from.h \
  /usr/include/c++/v1/__concepts/invocable.h \
  /usr/include/c++/v1/__functional/invoke.h \
  /usr/include/c++/v1/__concepts/predicate.h \
  /usr/include/c++/v1/__concepts/regular.h \
  /usr/include/c++/v1/__concepts/semiregular.h \
  /usr/include/c++/v1/__concepts/relation.h \
  /usr/include/c++/v1/__iterator/incrementable_traits.h \
  /usr/include/c++/v1/__type_traits/is_primary_template.h \
  /usr/include/c++/v1/__type_traits/is_valid_expansion.h \
  /usr/include/c++/v1/__iterator/iter_move.h \
  /usr/include/c++/v1/__iterator/iterator_traits.h \
  /usr/include/c++/v1/__iterator/readable_traits.h \
  /usr/include/c++/v1/__type_traits/detected_or.h \
  /usr/include/c++/v1/__memory/pointer_traits.h \
  /usr/include/c++/v1/__memory/addressof.h \
  /usr/include/c++/v1/__iterator/advance.h \
  /usr/include/c++/v1/__utility/convert_to_integral.h \
  /usr/include/c++/v1/__utility/unreachable.h \
  /usr/include/c++/v1/__iterator/distance.h \
  /usr/include/c++/v1/__ranges/access.h \
  /usr/include/c++/v1/__ranges/enable_borrowed_range.h \
  /usr/include/c++/v1/__utility/auto_cast.h \
  /usr/include/c++/v1/__ranges/concepts.h \
  /usr/include/c++/v1/__ranges/data.h \
  /usr/include/c++/v1/__ranges/enable_view.h \
  /usr/include/c++/v1/__ranges/size.h \
  /usr/include/c++/v1/__iterator/iter_swap.h \
  /usr/include/c++/v1/__iterator/next.h \
  /usr/include/c++/v1/__iterator/prev.h \
  /usr/include/c++/v1/__type_traits/is_callable.h \
  /usr/include/c++/v1/__algorithm/copy.h \
  /usr/include/c++/v1/__algorithm/copy_move_common.h \
  /usr/include/c++/v1/__algorithm/unwrap_iter.h \
  /usr/include/c++/v1/__algorithm/unwrap_range.h \
  /usr/include/c++/v1/__string/constexpr_c_functions.h \
  /usr/include/c++/v1/__memory/construct_at.h \
  /usr/include/c++/v1/__new/placement_new_delete.h \
  /usr/include/c++/v1/__type_traits/datasizeof.h \
  /usr/include/c++/v1/__type_traits/is_always_bitcastable.h \
  /usr/include/c++/v1/__type_traits/is_equality_comparable.h \
  /usr/include/c++/v1/__type_traits/is_trivially_lexicographically_comparable.h \
  /usr/include/c++/v1/__utility/element_count.h \
  /usr/include/c++/v1/__utility/is_pointer_in_range.h \
  /usr/include/c++/v1/__utility/is_valid_range.h \
  /usr/include/c++/v1/__algorithm/for_each_segment.h \
  /usr/include/c++/v1/__iterator/segmented_iterator.h \
  /usr/include/c++/v1/__algorithm/min.h \
  /usr/include/c++/v1/__algorithm/min_element.h \
  /usr/include/c++/v1/__fwd/bit_reference.h \
  /usr/include/c++/v1/__algorithm/copy_backward.h \
  /usr/include/c++/v1/__algorithm/copy_n.h \
  /usr/include/c++/v1/__algorithm/copy_if.h \
  /usr/include/c++/v1/__algorithm/count.h \
  /usr/include/c++/v1/__bit/invert_if.h \
  /usr/include/c++/v1/__bit/popcount.h \
  /usr/include/c++/v1/__type_traits/integer_traits.h \
  /usr/include/c++/v1/__algorithm/count_if.h \
  /usr/include/c++/v1/__algorithm/equal.h \
  /usr/include/c++/v1/__algorithm/equal_range.h \
  /usr/include/c++/v1/__algorithm/upper_bound.h \
  /usr/include/c++/v1/__algorithm/fill.h \
  /usr/include/c++/v1/__algorithm/fill_n.h \
  /usr/include/c++/v1/__algorithm/find.h \
  /usr/include/c++/v1/__algorithm/find_segment_if.h \
  /usr/include/c++/v1/__bit/countr.h /usr/include/c++/v1/cwchar \
  /usr/include/c++/v1/cwctype /usr/include/c++/v1/cctype \
  /usr/include/c++/v1/ctype.h /usr/include/ctype.h \
  /usr/include/xlocale/_ctype.h /usr/include/c++/v1/wctype.h \
  /usr/include/wctype.h /usr/include/c++/v1/wchar.h \
  /usr/include/c++/v1/__algorithm/find_end.h \
  /usr/include/c++/v1/__algorithm/find_first_of.h \
  /usr/include/c++/v1/__algorithm/find_if.h \
  /usr/include/c++/v1/__algorithm/find_if_not.h \
  /usr/include/c++/v1/__algorithm/for_each.h \
  /usr/include/c++/v1/__algorithm/generate.h \
  /usr/include/c++/v1/__algorithm/generate_n.h \
  /usr/include/c++/v1/__algorithm/includes.h \
  /usr/include/c++/v1/__algorithm/inplace_merge.h \
  /usr/include/c++/v1/__algorithm/move.h \
  /usr/include/c++/v1/__algorithm/rotate.h \
  /usr/include/c++/v1/__algorithm/move_backward.h \
  /usr/include/c++/v1/__algorithm/swap_ranges.h \
  /usr/include/c++/v1/__iterator/reverse_iterator.h \
  /usr/include/c++/v1/__compare/compare_three_way_result.h \
  /usr/include/c++/v1/__iterator/iterator.h \
  /usr/include/c++/v1/__ranges/subrange.h \
  /usr/include/c++/v1/__fwd/subrange.h \
  /usr/include/c++/v1/__ranges/dangling.h \
  /usr/include/c++/v1/__ranges/view_interface.h \
  /usr/include/c++/v1/__ranges/empty.h \
  /usr/include/c++/v1/__memory/destruct_n.h \
  /usr/include/c++/v1/__memory/unique_ptr.h \
  /usr/include/c++/v1/__compare/compare_three_way.h \
  /usr/include/c++/v1/__functional/hash.h \
  /usr/include/c++/v1/__functional/unary_function.h \
  /usr/include/c++/v1/__type_traits/is_unqualified.h \
  /usr/include/c++/v1/cstring /usr/include/c++/v1/string.h \
  /usr/include/string.h /usr/include/strings.h \
  /usr/include/xlocale/_strings.h /usr/include/xlocale/_string.h \
  /usr/include/c++/v1/__functional/operations.h \
  /usr/include/c++/v1/__functional/binary_function.h \
  /usr/include/c++/v1/__memory/allocator_traits.h \
  /usr/include/c++/v1/__memory/array_cookie.h \
  /usr/include/c++/v1/__memory/auto_ptr.h \
  /usr/include/c++/v1/__memory/compressed_pair.h \
  /usr/include/c++/v1/__type_traits/dependent_type.h \
  /usr/include/c++/v1/__type_traits/is_bounded_array.h \
  /usr/include/c++/v1/__type_traits/is_unbounded_array.h \
  /usr/include/c++/v1/__utility/private_constructor_tag.h \
  /usr/include/c++/v1/__memory/unique_temporary_buffer.h \
  /usr/include/c++/v1/__memory/allocator.h \
  /usr/include/c++/v1/__memory/allocate_at_least.h \
  /usr/include/c++/v1/__new/allocate.h \
  /usr/include/c++/v1/__new/align_val_t.h \
  /usr/include/c++/v1/__new/global_new_delete.h \
  /usr/include/c++/v1/__new/exceptions.h \
  /usr/include/c++/v1/__exception/exception.h \
  /usr/include/c++/v1/__new/nothrow_t.h \
  /usr/include/c++/v1/__algorithm/is_heap.h \
  /usr/include/c++/v1/__algorithm/is_heap_until.h \
  /usr/include/c++/v1/__algorithm/is_partitioned.h \
  /usr/include/c++/v1/__algorithm/is_permutation.h \
  /usr/include/c++/v1/__algorithm/is_sorted.h \
  /usr/include/c++/v1/__algorithm/is_sorted_until.h \
  /usr/include/c++/v1/__algorithm/lexicographical_compare.h \
  /usr/include/c++/v1/__algorithm/mismatch.h \
  /usr/include/c++/v1/__algorithm/simd_utils.h \
  /usr/include/c++/v1/__bit/bit_cast.h \
  /usr/include/c++/v1/__bit/countl.h /usr/include/c++/v1/__bit/rotate.h \
  /usr/include/c++/v1/__iterator/aliasing_iterator.h \
  /usr/include/c++/v1/__algorithm/make_heap.h \
  /usr/include/c++/v1/__algorithm/sift_down.h \
  /usr/include/c++/v1/__algorithm/max.h \
  /usr/include/c++/v1/__algorithm/max_element.h \
  /usr/include/c++/v1/__algorithm/merge.h \
  /usr/include/c++/v1/__algorithm/minmax.h \
  /usr/include/c++/v1/__algorithm/minmax_element.h \
  /usr/include/c++/v1/__algorithm/next_permutation.h \
  /usr/include/c++/v1/__algorithm/reverse.h \
  /usr/include/c++/v1/__algorithm/none_of.h \
  /usr/include/c++/v1/__algorithm/nth_element.h \
  /usr/include/c++/v1/__algorithm/sort.h \
  /usr/include/c++/v1/__algorithm/partial_sort.h \
  /usr/include/c++/v1/__algorithm/sort_heap.h \
  /usr/include/c++/v1/__algorithm/pop_heap.h \
  /usr/include/c++/v1/__algorithm/push_heap.h \
  /usr/include/c++/v1/__debug_utils/strict_weak_ordering_check.h \
  /usr/include/c++/v1/__debug_utils/randomize_range.h \
  /usr/include/c++/v1/__bit/bit_log2.h /usr/include/c++/v1/__bit/blsr.h \
  /usr/include/c++/v1/__functional/ranges_operations.h \
  /usr/include/c++/v1/climits /usr/include/limits.h \
  /usr/include/sys/limits.h /usr/include/sys/syslimits.h \
  /usr/include/c++/v1/__algorithm/partial_sort_copy.h \
  /usr/include/c++/v1/__algorithm/make_projected.h \
  /usr/include/c++/v1/__algorithm/partition.h \
  /usr/include/c++/v1/__algorithm/partition_copy.h \
  /usr/include/c++/v1/__algorithm/partition_point.h \
  /usr/include/c++/v1/__algorithm/prev_permutation.h \
  /usr/include/c++/v1/__algorithm/remove.h \
  /usr/include/c++/v1/__algorithm/remove_copy.h \
  /usr/include/c++/v1/__algorithm/remove_copy_if.h \
  /usr/include/c++/v1/__algorithm/remove_if.h \
  /usr/include/c++/v1/__algorithm/replace.h \
  /usr/include/c++/v1/__algorithm/replace_copy.h \
  /usr/include/c++/v1/__algorithm/replace_copy_if.h \
  /usr/include/c++/v1/__algorithm/replace_if.h \
  /usr/include/c++/v1/__algorithm/reverse_copy.h \
  /usr/include/c++/v1/__algorithm/rotate_copy.h \
  /usr/include/c++/v1/__algorithm/search.h \
  /usr/include/c++/v1/__algorithm/search_n.h \
  /usr/include/c++/v1/__algorithm/set_difference.h \
  /usr/include/c++/v1/__algorithm/set_intersection.h \
  /usr/include/c++/v1/__algorithm/set_symmetric_difference.h \
  /usr/include/c++/v1/__algorithm/set_union.h \
  /usr/include/c++/v1/__algorithm/shuffle.h \
  /usr/include/c++/v1/__random/uniform_int_distribution.h \
  /usr/include/c++/v1/__random/is_valid.h \
  /usr/include/c++/v1/__random/log2.h \
  /usr/include/c++/v1/__algorithm/stable_partition.h \
  /usr/include/c++/v1/__algorithm/stable_sort.h \
  /usr/include/c++/v1/__algorithm/radix_sort.h \
  /usr/include/c++/v1/__iterator/access.h \
  /usr/include/c++/v1/__iterator/move_iterator.h \
  /usr/include/c++/v1/__iterator/move_sentinel.h \
  /usr/include/c++/v1/__numeric/partial_sum.h \
  /usr/include/c++/v1/__algorithm/transform.h \
  /usr/include/c++/v1/__algorithm/unique.h \
  /usr/include/c++/v1/__algorithm/unique_copy.h \
  /usr/include/c++/v1/__algorithm/clamp.h \
  /usr/include/c++/v1/__algorithm/for_each_n.h \
  /usr/include/c++/v1/__algorithm/for_each_n_segment.h \
  /usr/include/c++/v1/__algorithm/pstl.h \
  /usr/include/c++/v1/__algorithm/sample.h \
  /usr/include/c++/v1/__atomic/aliases.h \
  /usr/include/c++/v1/__atomic/atomic.h \
  /usr/include/c++/v1/__atomic/atomic_sync.h \
  /usr/include/c++/v1/__atomic/contention_t.h \
  /usr/include/c++/v1/__atomic/support.h \
  /usr/include/c++/v1/__atomic/support/c11.h \
  /usr/include/c++/v1/__atomic/memory_order.h \
  /usr/include/c++/v1/__atomic/to_gcc_order.h \
  /usr/include/c++/v1/__chrono/duration.h /usr/include/c++/v1/ratio \
  /usr/include/c++/v1/__thread/poll_with_backoff.h \
  /usr/include/c++/v1/__chrono/high_resolution_clock.h \
  /usr/include/c++/v1/__chrono/steady_clock.h \
  /usr/include/c++/v1/__chrono/time_point.h \
  /usr/include/c++/v1/__chrono/system_clock.h /usr/include/c++/v1/ctime \
  /usr/include/time.h /usr/include/sys/_clock_id.h \
  /usr/include/sys/timespec.h /usr/include/sys/_timespec.h \
  /usr/include/xlocale/_time.h \
  /usr/include/c++/v1/__atomic/check_memory_order.h \
  /usr/include/c++/v1/__atomic/is_always_lock_free.h \
  /usr/include/c++/v1/__atomic/atomic_lock_free.h \
  /usr/include/c++/v1/__atomic/atomic_flag.h \
  /usr/include/c++/v1/__thread/support.h \
  /usr/include/c++/v1/__thread/support/pthread.h \
  /usr/include/c++/v1/__chrono/convert_to_timespec.h \
  /usr/include/c++/v1/errno.h /usr/include/errno.h \
  /usr/include/pthread.h /usr/include/sys/_pthreadtypes.h \
  /usr/include/sys/_sigset.h /usr/include/sys/_sigval.h \
  /usr/include/sched.h /usr/include/sys/types.h \
  /usr/include/machine/endian.h /usr/include/x86/endian.h \
  /usr/include/sys/_endian.h /usr/include/sys/bitcount.h \
  /usr/include/sys/select.h /usr/include/sys/_timeval.h \
  /usr/include/sys/sched.h /usr/include/sys/cpuset.h \
  /usr/include/sys/_cpuset.h /usr/include/sys/_bitset.h \
  /usr/include/sys/bitset.h /usr/include/c++/v1/__atomic/atomic_init.h \
  /usr/include/c++/v1/__atomic/fence.h \
  /usr/include/c++/v1/__atomic/kill_dependency.h /usr/include/c++/v1/bit \
  /usr/include/c++/v1/concepts /usr/include/c++/v1/iterator \
  /usr/include/c++/v1/__iterator/back_insert_iterator.h \
  /usr/include/c++/v1/__iterator/front_insert_iterator.h \
  /usr/include/c++/v1/__iterator/insert_iterator.h \
  /usr/include/c++/v1/__iterator/istream_iterator.h \
  /usr/include/c++/v1/__iterator/default_sentinel.h \
  /usr/include/c++/v1/__iterator/istreambuf_iterator.h \
  /usr/include/c++/v1/__string/char_traits.h /usr/include/c++/v1/cstdio \
  /usr/include/c++/v1/stdio.h /usr/include/stdio.h \
  /usr/include/c++/v1/__iterator/ostream_iterator.h \
  /usr/include/c++/v1/__iterator/ostreambuf_iterator.h \
  /usr/include/c++/v1/__iterator/wrap_iter.h \
  /usr/include/c++/v1/__iterator/reverse_access.h \
  /usr/include/c++/v1/__iterator/data.h \
  /usr/include/c++/v1/__iterator/empty.h \
  /usr/include/c++/v1/__iterator/size.h /usr/include/c++/v1/variant \
  /usr/include/c++/v1/__fwd/variant.h \
  /usr/include/c++/v1/__tuple/find_index.h \
  /usr/include/c++/v1/__tuple/sfinae_helpers.h \
  /usr/include/c++/v1/__tuple/make_tuple_types.h \
  /usr/include/c++/v1/__tuple/tuple_like_ext.h \
  /usr/include/c++/v1/__utility/forward_like.h \
  /usr/include/c++/v1/__variant/monostate.h \
  /usr/include/c++/v1/exception \
  /usr/include/c++/v1/__exception/exception_ptr.h \
  /usr/include/c++/v1/__exception/operations.h \
  /usr/include/c++/v1/typeinfo \
  /usr/include/c++/v1/__exception/nested_exception.h \
  /usr/include/c++/v1/__exception/terminate.h /usr/include/c++/v1/new \
  /usr/include/c++/v1/__new/new_handler.h \
  /usr/include/c++/v1/__new/interference_size.h \
  /usr/include/c++/v1/__new/launder.h /usr/include/c++/v1/tuple \
  /usr/include/c++/v1/__memory/allocator_arg_t.h \
  /usr/include/c++/v1/__memory/uses_allocator.h \
  /usr/include/c++/v1/__type_traits/maybe_const.h \
  /usr/include/c++/v1/__type_traits/reference_constructs_from_temporary.h \
  /usr/include/c++/v1/memory /usr/include/c++/v1/__memory/align.h \
  /usr/include/c++/v1/__memory/inout_ptr.h \
  /usr/include/c++/v1/__memory/shared_ptr.h \
  /usr/include/c++/v1/__functional/reference_wrapper.h \
  /usr/include/c++/v1/__functional/weak_result_type.h \
  /usr/include/c++/v1/__type_traits/is_specialization.h \
  /usr/include/c++/v1/__memory/allocation_guard.h \
  /usr/include/c++/v1/__memory/allocator_destructor.h \
  /usr/include/c++/v1/__memory/destroy.h \
  /usr/include/c++/v1/__memory/shared_count.h \
  /usr/include/c++/v1/__memory/uninitialized_algorithms.h \
  /usr/include/c++/v1/__utility/exception_guard.h \
  /usr/include/c++/v1/__memory/is_sufficiently_aligned.h \
  /usr/include/c++/v1/__memory/out_ptr.h \
  /usr/include/c++/v1/__memory/raw_storage_iterator.h \
  /usr/include/c++/v1/__memory/temporary_buffer.h \
  /usr/include/c++/v1/stdexcept /usr/include/c++/v1/optional \
  /usr/local/include/qt6/QtCore/qatomic.h \
  /usr/local/include/qt6/QtCore/qbasicatomic.h \
  /usr/local/include/qt6/QtCore/qatomic_cxx11.h \
  /usr/local/include/qt6/QtCore/qgenericatomic.h \
  /usr/local/include/qt6/QtCore/qyieldcpu.h \
  /usr/local/include/qt6/QtCore/qconstructormacros.h \
  /usr/local/include/qt6/QtCore/qdarwinhelpers.h \
  /usr/local/include/qt6/QtCore/qexceptionhandling.h \
  /usr/local/include/qt6/QtCore/qforeach.h \
  /usr/local/include/qt6/QtCore/qttypetraits.h \
  /usr/local/include/qt6/QtCore/qfunctionpointer.h \
  /usr/local/include/qt6/QtCore/qglobalstatic.h \
  /usr/local/include/qt6/QtCore/qmalloc.h \
  /usr/local/include/qt6/QtCore/qminmax.h \
  /usr/local/include/qt6/QtCore/qnumeric.h \
  /usr/local/include/qt6/QtCore/q20type_traits.h \
  /usr/local/include/qt6/QtCore/qoverload.h \
  /usr/local/include/qt6/QtCore/qswap.h \
  /usr/local/include/qt6/QtCore/qtenvironmentvariables.h \
  /usr/local/include/qt6/QtCore/qtresource.h \
  /usr/local/include/qt6/QtCore/qttranslation.h \
  /usr/local/include/qt6/QtCore/qversiontagging.h \
  /usr/local/include/qt6/QtCore/qcompare.h \
  /usr/local/include/qt6/QtCore/qstdlibdetection.h \
  /usr/local/include/qt6/QtCore/qcomparehelpers.h \
  /usr/include/c++/v1/functional \
  /usr/include/c++/v1/__functional/binary_negate.h \
  /usr/include/c++/v1/__functional/bind.h \
  /usr/include/c++/v1/__functional/binder1st.h \
  /usr/include/c++/v1/__functional/binder2nd.h \
  /usr/include/c++/v1/__functional/mem_fn.h \
  /usr/include/c++/v1/__functional/mem_fun_ref.h \
  /usr/include/c++/v1/__functional/pointer_to_binary_function.h \
  /usr/include/c++/v1/__functional/pointer_to_unary_function.h \
  /usr/include/c++/v1/__functional/unary_negate.h \
  /usr/include/c++/v1/__functional/function.h \
  /usr/include/c++/v1/__type_traits/strip_signature.h \
  /usr/include/c++/v1/__functional/boyer_moore_searcher.h \
  /usr/include/c++/v1/array \
  /usr/include/c++/v1/__algorithm/lexicographical_compare_three_way.h \
  /usr/include/c++/v1/__algorithm/three_way_comp_ref_type.h \
  /usr/include/c++/v1/__iterator/static_bounded_iter.h \
  /usr/include/c++/v1/unordered_map \
  /usr/include/c++/v1/__functional/is_transparent.h \
  /usr/include/c++/v1/__hash_table \
  /usr/include/c++/v1/__memory/swap_allocator.h \
  /usr/include/c++/v1/__type_traits/can_extract_key.h \
  /usr/include/c++/v1/__type_traits/remove_const_ref.h \
  /usr/include/c++/v1/__iterator/erase_if_container.h \
  /usr/include/c++/v1/__iterator/ranges_iterator_traits.h \
  /usr/include/c++/v1/__memory_resource/polymorphic_allocator.h \
  /usr/include/c++/v1/__memory_resource/memory_resource.h \
  /usr/include/c++/v1/__node_handle \
  /usr/include/c++/v1/__ranges/container_compatible_range.h \
  /usr/include/c++/v1/__ranges/from_range.h \
  /usr/include/c++/v1/__type_traits/container_traits.h \
  /usr/include/c++/v1/__type_traits/is_allocator.h \
  /usr/include/c++/v1/__functional/default_searcher.h \
  /usr/include/c++/v1/__functional/not_fn.h \
  /usr/include/c++/v1/__functional/perfect_forward.h \
  /usr/include/c++/v1/vector /usr/include/c++/v1/__vector/comparison.h \
  /usr/include/c++/v1/__fwd/vector.h /usr/include/c++/v1/__vector/swap.h \
  /usr/include/c++/v1/__vector/vector.h \
  /usr/include/c++/v1/__algorithm/ranges_copy_n.h \
  /usr/include/c++/v1/__algorithm/in_out_result.h \
  /usr/include/c++/v1/__algorithm/ranges_copy.h \
  /usr/include/c++/v1/__iterator/unreachable_sentinel.h \
  /usr/include/c++/v1/__debug_utils/sanitizers.h \
  /usr/include/c++/v1/__format/enable_insertable.h \
  /usr/include/c++/v1/__iterator/bounded_iter.h \
  /usr/include/c++/v1/__memory/noexcept_move_assign_container.h \
  /usr/include/c++/v1/__memory/temp_value.h \
  /usr/include/c++/v1/__split_buffer \
  /usr/include/c++/v1/__vector/container_traits.h \
  /usr/include/c++/v1/__vector/vector_bool.h \
  /usr/include/c++/v1/__bit_reference /usr/include/c++/v1/__vector/pmr.h \
  /usr/include/c++/v1/cerrno /usr/include/c++/v1/clocale \
  /usr/include/locale.h /usr/include/xlocale/_locale.h \
  /usr/include/c++/v1/locale /usr/include/c++/v1/__locale \
  /usr/include/c++/v1/__locale_dir/locale_base_api.h \
  /usr/include/c++/v1/__locale_dir/support/freebsd.h \
  /usr/include/c++/v1/__locale_dir/support/bsd_like.h \
  /usr/include/xlocale.h /usr/include/xlocale/_stdlib.h \
  /usr/include/xlocale/_stdio.h /usr/include/c++/v1/__mutex/once_flag.h \
  /usr/include/c++/v1/__utility/no_destroy.h /usr/include/c++/v1/string \
  /usr/include/c++/v1/__ios/fpos.h \
  /usr/include/c++/v1/__string/extern_template_lists.h \
  /usr/include/c++/v1/__utility/scope_guard.h \
  /usr/include/c++/v1/string_view \
  /usr/include/c++/v1/__fwd/string_view.h \
  /usr/include/c++/v1/__locale_dir/messages.h /usr/include/nl_types.h \
  /usr/include/c++/v1/__locale_dir/money.h \
  /usr/include/c++/v1/__locale_dir/check_grouping.h \
  /usr/include/c++/v1/ios \
  /usr/include/c++/v1/__system_error/error_category.h \
  /usr/include/c++/v1/__system_error/error_code.h \
  /usr/include/c++/v1/__system_error/errc.h \
  /usr/include/c++/v1/__system_error/error_condition.h \
  /usr/include/c++/v1/__system_error/system_error.h \
  /usr/include/c++/v1/mutex \
  /usr/include/c++/v1/__condition_variable/condition_variable.h \
  /usr/include/c++/v1/__mutex/mutex.h \
  /usr/include/c++/v1/__mutex/unique_lock.h \
  /usr/include/c++/v1/__mutex/tag_types.h \
  /usr/include/c++/v1/__system_error/throw_system_error.h \
  /usr/include/c++/v1/__mutex/lock_guard.h \
  /usr/include/c++/v1/__thread/id.h /usr/include/c++/v1/system_error \
  /usr/include/c++/v1/__locale_dir/get_c_locale.h \
  /usr/include/c++/v1/__locale_dir/pad_and_output.h \
  /usr/include/c++/v1/__locale_dir/num.h \
  /usr/include/c++/v1/__charconv/to_chars_integral.h \
  /usr/include/c++/v1/__charconv/tables.h \
  /usr/include/c++/v1/__charconv/to_chars_base_10.h \
  /usr/include/c++/v1/__charconv/to_chars_result.h \
  /usr/include/c++/v1/__charconv/traits.h \
  /usr/include/c++/v1/__type_traits/make_32_64_or_128_bit.h \
  /usr/include/c++/v1/__locale_dir/scan_keyword.h \
  /usr/include/c++/v1/streambuf /usr/include/c++/v1/__locale_dir/time.h \
  /usr/include/c++/v1/__locale_dir/wbuffer_convert.h \
  /usr/include/c++/v1/__locale_dir/wstring_convert.h \
  /usr/include/c++/v1/cstdarg /usr/include/stdarg.h \
  /usr/include/sys/_stdarg.h /usr/local/include/qt6/QtCore/qstringview.h \
  /usr/local/include/qt6/QtCore/qbytearray.h \
  /usr/local/include/qt6/QtCore/qrefcount.h \
  /usr/local/include/qt6/QtCore/qnamespace.h \
  /usr/local/include/qt6/QtCore/qtmetamacros.h \
  /usr/local/include/qt6/QtCore/qarraydata.h \
  /usr/local/include/qt6/QtCore/qpair.h \
  /usr/local/include/qt6/QtCore/qarraydatapointer.h \
  /usr/local/include/qt6/QtCore/qarraydataops.h \
  /usr/local/include/qt6/QtCore/qcontainertools_impl.h \
  /usr/local/include/qt6/QtCore/qxptype_traits.h \
  /usr/local/include/qt6/QtCore/q23type_traits.h \
  /usr/local/include/qt6/QtCore/q20functional.h \
  /usr/local/include/qt6/QtCore/q20memory.h \
  /usr/local/include/qt6/QtCore/q17memory.h \
  /usr/local/include/qt6/QtCore/qbytearrayalgorithms.h \
  /usr/local/include/qt6/QtCore/qbytearrayview.h \
  /usr/local/include/qt6/QtCore/qstringfwd.h \
  /usr/local/include/qt6/QtCore/qstringalgorithms.h \
  /usr/local/include/qt6/QtCore/qlatin1stringview.h \
  /usr/local/include/qt6/QtCore/qanystringview.h \
  /usr/local/include/qt6/QtCore/qutf8stringview.h \
  /usr/local/include/qt6/QtCore/qstringtokenizer.h \
  /usr/local/include/qt6/QtCore/qstringbuilder.h \
  /usr/local/include/qt6/QtCore/qstringconverter.h \
  /usr/local/include/qt6/QtCore/qstringconverter_base.h \
  /usr/local/include/qt6/QtCore/QStringList \
  /usr/local/include/qt6/QtCore/qstringlist.h \
  /usr/local/include/qt6/QtCore/qlist.h \
  /usr/local/include/qt6/QtCore/qhashfunctions.h \
  /usr/include/c++/v1/numeric /usr/include/c++/v1/__numeric/accumulate.h \
  /usr/include/c++/v1/__numeric/adjacent_difference.h \
  /usr/include/c++/v1/__numeric/inner_product.h \
  /usr/include/c++/v1/__numeric/iota.h \
  /usr/include/c++/v1/__numeric/exclusive_scan.h \
  /usr/include/c++/v1/__numeric/gcd_lcm.h \
  /usr/include/c++/v1/__numeric/inclusive_scan.h \
  /usr/include/c++/v1/__numeric/pstl.h \
  /usr/include/c++/v1/__numeric/ranges_iota.h \
  /usr/include/c++/v1/__algorithm/out_value_result.h \
  /usr/include/c++/v1/__numeric/reduce.h \
  /usr/include/c++/v1/__numeric/transform_exclusive_scan.h \
  /usr/include/c++/v1/__numeric/transform_inclusive_scan.h \
  /usr/include/c++/v1/__numeric/transform_reduce.h \
  /usr/include/c++/v1/execution \
  /usr/include/c++/v1/__type_traits/is_execution_policy.h \
  /usr/local/include/qt6/QtCore/qiterator.h \
  /usr/local/include/qt6/QtCore/qbytearraylist.h \
  /usr/local/include/qt6/QtCore/qalgorithms.h \
  /usr/local/include/qt6/QtCore/q20bit.h \
  /usr/local/include/qt6/QtCore/qstringmatcher.h \
  /usr/local/include/qt6/QtCore/QMap \
  /usr/local/include/qt6/QtCore/qmap.h \
  /usr/local/include/qt6/QtCore/qscopeguard.h \
  /usr/local/include/qt6/QtCore/qshareddata.h \
  /usr/local/include/qt6/QtCore/qshareddata_impl.h \
  /usr/include/c++/v1/map /usr/include/c++/v1/__fwd/map.h \
  /usr/include/c++/v1/__tree /usr/include/c++/v1/__fwd/set.h
