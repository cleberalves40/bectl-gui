# Empty dependencies file for bectl_gui.
# This may be replaced when dependencies are built.
