file(REMOVE_RECURSE
  "CMakeFiles/bectl_gui.dir/link.d"
  "CMakeFiles/bectl_gui_autogen.dir/AutogenUsed.txt"
  "CMakeFiles/bectl_gui_autogen.dir/ParseCache.txt"
  "bectl_gui_autogen"
  "CMakeFiles/bectl_gui.dir/bectl_gui_autogen/mocs_compilation.cpp.o"
  "CMakeFiles/bectl_gui.dir/bectl_gui_autogen/mocs_compilation.cpp.o.d"
  "CMakeFiles/bectl_gui.dir/src/gui/mainwindow.cpp.o"
  "CMakeFiles/bectl_gui.dir/src/gui/mainwindow.cpp.o.d"
  "CMakeFiles/bectl_gui.dir/src/gui/themes.cpp.o"
  "CMakeFiles/bectl_gui.dir/src/gui/themes.cpp.o.d"
  "CMakeFiles/bectl_gui.dir/src/logic/bectlmanager.cpp.o"
  "CMakeFiles/bectl_gui.dir/src/logic/bectlmanager.cpp.o.d"
  "CMakeFiles/bectl_gui.dir/src/main.cpp.o"
  "CMakeFiles/bectl_gui.dir/src/main.cpp.o.d"
  "bectl_gui"
  "bectl_gui.pdb"
  "bectl_gui_autogen/mocs_compilation.cpp"
  "bectl_gui_autogen/timestamp"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/bectl_gui.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
