file(REMOVE_RECURSE
  "CMakeFiles/bectl_gui_autogen"
  "bectl_gui_autogen/mocs_compilation.cpp"
  "bectl_gui_autogen/timestamp"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/bectl_gui_autogen.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
